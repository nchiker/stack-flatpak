This conservative dependency inventory includes build-time dependencies and some cfg-disabled platform code.
Complete Rust and application desktop source (SOURCE.tar.gz, including embedded attribution) is published at:
https://github.com/nchiker/stack/releases/tag/desktop-v0.7.0
Upstream notice URLs/revisions/hashes are in upstream/PROVENANCE.json.
Some published crates omit standalone license files: declarations retain upstream authors and standard SPDX supplements are labeled.
Native PDFium/OCR notices and engine provenance are in runtime/.
To inspect/rebuild Rust source: extract SOURCE.tar.gz, cd source/desktop, cargo build --offline --locked --release.
The recorded Rust toolchain and documented Ubuntu native development dependencies are required; runtimes are supplied separately in this package.
